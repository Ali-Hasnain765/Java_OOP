public class Main {
    public static void main(String[] args) {
        Technology karim= new Technology();
        karim.setName("Karim");
        karim.setDepartment("Technology");
        karim.setSalary(50000);
        karim.setExLvl("3 Years");
        karim.setGender("Male");
        karim.display();
    }
    }
