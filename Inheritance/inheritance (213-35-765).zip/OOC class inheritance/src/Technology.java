public class Technology extends Employee {
}
