public interface OnlinePayment {
    float paymentCharge();
    void paymentConfirmation();
}
