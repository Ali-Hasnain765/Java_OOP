public class MainInheritance {
    public static void main(String[] args) {
        OnlinePayment b = new Bkash();
        OnlinePayment n = new Nagad();
        OnlinePayment r = new Rocket();
        System.out.println("Bkash Payment Charge: "+b.paymentCharge());
        b.paymentConfirmation();
        System.out.println("Nagad Payment Charge: "+b.paymentCharge());
        n.paymentConfirmation();
        System.out.println("R Payment Charge: "+b.paymentCharge());
        r.paymentConfirmation();
    }
}