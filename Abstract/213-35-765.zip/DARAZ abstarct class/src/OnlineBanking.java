public abstract class OnlineBanking {
    public float paymentCharge(){
        return 10.50f;
    }
    public abstract void paymentConfirmation();
}
