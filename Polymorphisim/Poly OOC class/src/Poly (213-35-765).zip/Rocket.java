public class Rocket extends OnlineBanking{
    @Override
    public float cashOutCharge() {
        return 9.50f;
    }
}
