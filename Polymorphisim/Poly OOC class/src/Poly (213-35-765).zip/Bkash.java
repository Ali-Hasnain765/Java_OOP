public class Bkash extends OnlineBanking{
    @Override
    public float cashOutCharge() {
        return 14.90f;
    }
}
