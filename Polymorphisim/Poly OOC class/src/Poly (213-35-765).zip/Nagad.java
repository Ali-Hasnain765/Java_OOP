public class Nagad extends OnlineBanking{
    @Override
    public float cashOutCharge() {
        return 10.99f;
    }
}
